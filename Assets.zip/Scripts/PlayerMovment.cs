﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovment : MonoBehaviour {
    //Controll Variables
    [Tooltip("Velocidade de movimento")]
    [SerializeField] float MaxSpeed;
    [Tooltip("multiplicador de velocidade na animação de corrida")]
    [SerializeField,Range(1,3)] float RunMultiplicator = 1;
    [Tooltip("força do pulo")]
    [SerializeField] float JumpStrength;
    [Tooltip("Colisores de ataque")]
    [SerializeField] GameObject HitPunch, HitKick;
    [Tooltip("Position to create cloud effects ")]
    [SerializeField] Transform leftFoot, rigthFoot;
    [Tooltip("effect to create on each step")]
    [SerializeField] GameObject stepCloud,stepSand;


    //InstanceVariables    
    Vector3 moveDirection; // direção de movimento
    Transform cam; //referencia da câmera
    Rigidbody RB; //Referencia para o rigidBody
    Animator anim; //Referencia para o animator
    bool isOnGroung; //jogador está no chão
    int timeOnIddle; //tempo para acionar a animação de idle secundária 
    int punchTimeOut, kickTimeOut; // tempo para resetar as variaveis de imput do animator
    public bool cantMove; // trava a movimentação do jogador    
    GameObject StepEffect;
    

    //Functions
    private void Start()
    {
        cam = Camera.main.transform;
        RB = this.GetComponent<Rigidbody>();
        anim = this.GetComponent<Animator>();
        DisablePunchCollider();
        DisableKickCollider();
        StepEffect = stepCloud;
    }

    private void Update()
    {
        if (!cantMove) //movimenta o personagem
        {
            float vAxis = Input.GetAxis("Vertical");
            float hAxis = Input.GetAxis("Horizontal");
            Vector3 direction = new Vector3(hAxis, 0, vAxis); //Direção de input do jogador
            if (isOnGroung)
            {
                anim.SetFloat("speed", direction.magnitude); //animação de movimento dependendo da velocidade
            }
            if (Mathf.Abs(vAxis) > 0.1 || Mathf.Abs(hAxis) > 0.1) //input de movimento aceito
            {
                float RM = 1;
                if (anim.GetFloat("speed") > 0.9) RM = RunMultiplicator;
                SetAngle(hAxis, vAxis); //gira o personagem para a direção desejada
                RB.AddForce(transform.forward * direction.magnitude * MaxSpeed*RM); //acelera o personagem
                timeOnIddle = 0; //input recebido, zera o tempo para idle secundário
            }
        }
        
        if(Input.GetButtonDown("Jump"))// pulo
        {
            if(isOnGroung) //Verificação de input válido
            {
                RB.AddForce(0, JumpStrength*100, 0);
                anim.SetBool("jump",true);
                timeOnIddle = 0;  //input recebido, zera o tempo para idle secundário
            }
        }

        if (Input.GetButtonDown("Fire1")) //soco
        {
            anim.SetBool("punch", true);
            timeOnIddle = 0;  //input recebido, zera o tempo para idle secundário
            punchTimeOut = 30; //tempo minimo para acionar o input novamente           
        }

        if (Input.GetButtonDown("Fire2")) //chute
        {
            anim.SetBool("kick", true);
            timeOnIddle = 0;  //input recebido, zera o tempo para idle secundário
            kickTimeOut = 30;  //tempo minimo para acionar o input novamente           
        }
    }

    private void FixedUpdate()
    {
        //incrementa as variaveis auxiliares
        punchTimeOut--;
        kickTimeOut--;
        timeOnIddle++;        
        Checkground();//verifica se o personagem está no chão
        if (!isOnGroung) RB.AddForce(0, -100, 0); //gravidade auxiliar
        if(timeOnIddle >500) // chamada da animação de idle secundária
        {
            timeOnIddle = 0;
            anim.SetTrigger("idle");
        }
        //libera a realização de novos inputs de soco e chute
        if(punchTimeOut == 0)
        {
            anim.SetBool("punch", false);
            
        }
        if (kickTimeOut == 0)
        {            
            anim.SetBool("kick", false);
            
        }
    }

    //orienta o personagem na direção do input em relação a direção da câmera
    void SetAngle(float hAxis,float vAxis)
    {
        moveDirection = new Vector3(hAxis, 0, vAxis); //direção de input do jogador
        Vector3 camForward = cam.forward; // direção do forward da câmera
        camForward.y = 0;
        //gira o personagem temporáriamente na direção do input e armazena a rotação em R1
        transform.LookAt(moveDirection*100);
        float R1 = transform.eulerAngles.y;
        //gira o personagem temporáriamente na direção da camera e armazena a rotação em R2
        transform.LookAt(camForward*100);
        float R2 = transform.eulerAngles.y;
        transform.eulerAngles = new Vector3(0, R1 + R2, 0); //Rotação final, soma de R1 e R2
        
    }    

    //verifica se o personagem está no chão
    void Checkground()
    {
        Ray ray = new Ray(transform.position, new Vector3(0, -1, 0));
        RaycastHit hit;
        if (Physics.Raycast(ray,out hit, 0.1f) && RB.velocity.y <= 0.1f)
        {
            isOnGroung = true;
            anim.SetBool("jump", false);
            string groundMaterial = hit.collider.material.name;
            if (groundMaterial.Contains("sand")) StepEffect = stepSand;
            else StepEffect = stepCloud;
            Debug.Log(groundMaterial);
        }
        else isOnGroung = false;
    }

    //funções publicas para acesso via animation events

    public void EndAtk() // fim de um ataque /libera movimento
    {
        cantMove = false;
    }
    public void LockMovent() //trava o movimento
    {
        cantMove = true;
    }
    public void DisablePunchCollider()//Desligar colisor de soco
    {
        HitPunch.SetActive(false);
    }
    public void EnablePunchCollider()//Ligar colisor de soco
    {
        HitPunch.SetActive(true);
    }
    public void DisableKickCollider()//Desligar colisor de chute
    {
        HitKick.SetActive(false);
    }
    public void EnableKickCollider()//Ligar colisor de soco
    {
        HitKick.SetActive(true);
    }
    public void leftStep()
    {
       Instantiate(StepEffect, leftFoot.position, transform.rotation);
        
    }
    public void rigthStep()
    {
        Instantiate(StepEffect, rigthFoot.position, transform.rotation);
    }
        
}
