﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraControl : MonoBehaviour {
    //Control Variables
    [Tooltip("velocidade de movimentação da camera")]
    [SerializeField] float CameraMoveSpeed;
    [Tooltip("Ajuste na posição do foco da câmera")]
    [SerializeField] Vector3 FocusAjustment;
    [Tooltip("limite Min e Max de angulos na vertical")]
    [SerializeField] Vector2 LimitAngles;
    [Tooltip("Velocidade de giro da câmera")]
    [SerializeField] float rotateSpeed;
    [Tooltip("disables camera's mouse control")]
    [SerializeField] bool disableMouseCamera;
    [Tooltip("Multiplicador de Velocidade do mouse")]
    [SerializeField] float mouseSensibility = 5;

    //Variables
    Transform mainCamera; //referencia para a camera do jogo
    GameObject CameraTargetPosition; //Posição que a câmera tenta seguir
    GameObject CameraPivot; // Centro de giro da câmera
    public float horizontalValue,verticalValue; // Auxiliares para Rotação
    Vector3 mouseLast; //ultima posição do mouse

    // Use this for initialization
    void Start () {
        mainCamera = Camera.main.transform;
        //pivot criado e definido como posição do jogador
        CameraPivot = new GameObject();
        CameraPivot.name = "cameraPivot";
        CameraPivot.transform.position = transform.position;
        //target da camera criado e iniciado na posição atual da câmera
        CameraTargetPosition = new GameObject();
        CameraTargetPosition.name = "CameraTargetPosition";
        CameraTargetPosition.transform.position = mainCamera.transform.position;
        CameraTargetPosition.transform.parent = CameraPivot.transform;        
    }

    private void Update()
    {
        //Input de camera para teclado e Controle
        if (Input.GetAxis("HorizontalCam")<0) RotateHorizontal(-rotateSpeed);
        else if (Input.GetAxis("HorizontalCam") > 0) RotateHorizontal(rotateSpeed);
        if (Input.GetAxis("VerticalCam") > 0) RotateVertical(-rotateSpeed);
        else if (Input.GetAxis("VerticalCam") < 0) RotateVertical(rotateSpeed);
        //Input de camera do Mouse
        MouseCameraControl();
    }
    
    //movimentação da câmera com mouse
    void MouseCameraControl()
    {
        if (!disableMouseCamera)
        {
            //Compara a ultima posição do mouse com a posição atual para rotacinar a câmera
            if (mouseLast.x > Input.mousePosition.x + 1) RotateHorizontal(-rotateSpeed * mouseSensibility);
            else if (mouseLast.x < Input.mousePosition.x - 1) RotateHorizontal(rotateSpeed * mouseSensibility);
            if (mouseLast.y > Input.mousePosition.y + 1) RotateVertical(rotateSpeed);
            else if (mouseLast.y < Input.mousePosition.y - 1) RotateVertical(-rotateSpeed);
            //atualiza posição do mouse
            mouseLast = Input.mousePosition;
        }
    }

    void FixedUpdate () {
        //atualiza a posição do pivot para a posição do personagem
        CameraPivot.transform.position = transform.position;
        //Vetor de direção de movimento da camera em direção à posição alvo
        Vector3 moveDirection = CameraTargetPosition.transform.position - mainCamera.position;
        //Caso a distancia seja maior que o limite, movimenta a camera
        if(Mathf.Abs(moveDirection.magnitude)>CameraMoveSpeed*2)
        {
            mainCamera.transform.position += moveDirection.normalized * CameraMoveSpeed;
        }
        //Para pequenas distancias atualiza a posição da camera instantâneamente
        else
        {
            mainCamera.transform.position = CameraTargetPosition.transform.position;
        }
        //ajusta a direção da câmera
        mainCamera.LookAt(transform.position + FocusAjustment);       


    }
    //Gira a câmera na Horizontal
    void RotateHorizontal(float speed)
    {
        horizontalValue += speed;

        CameraPivot.transform.eulerAngles = new Vector3(verticalValue,horizontalValue,0);
    }
    //Gira a câmera na vertical, conciderando os valores limites
    void RotateVertical(float speed)
    {
        verticalValue += speed;
        if (verticalValue < LimitAngles.x) verticalValue = LimitAngles.x;
        if (verticalValue > LimitAngles.y) verticalValue = LimitAngles.y;
        CameraPivot.transform.eulerAngles = new Vector3(verticalValue, horizontalValue, 0);

    }
}
