﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectsUtility : MonoBehaviour {
    [Tooltip("enable random Rotation")]
    [SerializeField] bool randomRotation;

    [Tooltip("Inicia o objeto com rotação aleatória entre os Valores Min e Max")]
    [SerializeField] Vector3 RandomRotateMin, RandomRotateMax;


	// Use this for initialization
	void Start () {
        //Inicia a rotação do objeto com um valor entre o Min e Max determinado
        if (randomRotation)
        {
            float x, y, z;
            x = Random.Range(RandomRotateMin.x, RandomRotateMax.x);
            y = Random.Range(RandomRotateMin.y, RandomRotateMax.y);
            z = Random.Range(RandomRotateMin.z, RandomRotateMax.z);
            transform.eulerAngles = new Vector3(x, y, z);
        }
    }

    //Função acessivel em eventos de animação para destruir o objeto. 
    public void DestroyThisInstance()
    {
        Destroy(this.gameObject);
    }
}
