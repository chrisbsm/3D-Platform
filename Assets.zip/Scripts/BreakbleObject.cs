﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BreakbleObject : MonoBehaviour {
    Animator anim; //Referencia para o Animator deste objeto
    [Tooltip("determina quantos ataques são necessários para o objeto quebrar")]
    [SerializeField] int life;
    [Tooltip("efeito instanciado ao quebrar o objeto")]
    [SerializeField] GameObject BreakEffect;

	// Use this for initialization
	void Start () {
        anim = this.GetComponent<Animator>();	
	}

    private void OnTriggerEnter(Collider other)
    {
        if(other.tag == "atk") //colisão com ataque do jogador
        {
            anim.SetTrigger("hit"); //Chamada da animação de feedback
            life--;
            if (life == 0)
            {
                Destroy(this.gameObject);
                if (BreakEffect != null)
                {
                    Instantiate(BreakEffect, transform.position, transform.rotation);
                }
            }
        }
    }

}
